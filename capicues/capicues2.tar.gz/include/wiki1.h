#ifndef _WIKI_H
#define _WIKI_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
	long valor;
	void *siguiente;
} pila1;

#include <headings1.h>

#endif
